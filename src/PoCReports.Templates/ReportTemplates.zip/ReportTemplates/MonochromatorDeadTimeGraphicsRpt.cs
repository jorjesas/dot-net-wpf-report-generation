using System;
using System.Collections.Generic;
using DevExpress.XtraReports.UI;
using PoCReports.Models;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class MonochromatorDeadTimeGraphicsRpt
    {
        public MonochromatorDeadTimeGraphicsRpt()
        {
            InitializeComponent();

            chart1.DataSource = GetCombinedSeriesData();
        }

        private IList<GoniometerScanGraphicsDTO> GetSeries1Data()
        {
            return new List<GoniometerScanGraphicsDTO>
            {
                new GoniometerScanGraphicsDTO { Intensity = 75, Angle = 7},
                new GoniometerScanGraphicsDTO { Intensity = 240, Angle = 20},
                new GoniometerScanGraphicsDTO { Intensity = 420, Angle = 30},
                new GoniometerScanGraphicsDTO { Intensity = 570, Angle = 40},
                new GoniometerScanGraphicsDTO { Intensity = 690, Angle = 50},
                new GoniometerScanGraphicsDTO { Intensity = 800, Angle = 60},
            };
        }

        private IList<GoniometerScanGraphicsDTO> GetSeries2Data()
        {
            return new List<GoniometerScanGraphicsDTO>
            {
                new GoniometerScanGraphicsDTO { Intensity = 75, Angle = 7},
                new GoniometerScanGraphicsDTO { Intensity = 105, Angle = 10},
                new GoniometerScanGraphicsDTO { Intensity = 220, Angle = 20},
                new GoniometerScanGraphicsDTO { Intensity = 400, Angle = 30},
                new GoniometerScanGraphicsDTO { Intensity = 540, Angle = 40},
                new GoniometerScanGraphicsDTO { Intensity = 650, Angle = 50},
                new GoniometerScanGraphicsDTO { Intensity = 730, Angle = 60},
            };
        }

        private IList<GoniometerScanGraphicsCombinedSeriesDTO> GetCombinedSeriesData()
        {
            return new List<GoniometerScanGraphicsCombinedSeriesDTO>
            {
                new GoniometerScanGraphicsCombinedSeriesDTO
                {
                    GoniometerScanGraphicsSeries1 = GetSeries1Data(),
                    GoniometerScanGraphicsSeries2 = GetSeries2Data()
                }
            };
        }
    }
}
