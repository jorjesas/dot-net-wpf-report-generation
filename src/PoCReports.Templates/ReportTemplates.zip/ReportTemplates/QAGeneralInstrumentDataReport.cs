using System;
using DevExpress.XtraReports.UI;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class QAGeneralInstrumentDataReport
    {
        public QAGeneralInstrumentDataReport()
        {
            InitializeComponent();
        }
    }
}
