using System;
using System.Collections.Generic;
using DevExpress.XtraCharts;
using DevExpress.XtraReports.UI;
using PoCReports.Models;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class GoniometerScanGraphicsCombinedSeriesRpt
    {
        public GoniometerScanGraphicsCombinedSeriesRpt()
        {
            InitializeComponent();

            //this.Detail.Controls.Add(CreateChart());

            chart1.DataSource = GetData();
        }

        private XRControl CreateChart()
        {
            XRChart xrChart1 = new XRChart();
            xrChart1.WidthF = 640;
            xrChart1.HeightF = 400;

            xrChart1.DataSource = GetData();

            Series series1 = new Series("Spline Series 1", ViewType.Spline);
            series1.ArgumentDataMember = "GoniometerScanGraphicsSeries1.Angle";
            series1.ValueDataMembers.AddRange(new string[] { "GoniometerScanGraphicsSeries1.Intensity" });
            series1.Visible = true;

            Series series2 = new Series("Spline Series 2", ViewType.Spline);
            series2.ArgumentDataMember = "GoniometerScanGraphicsSeries2.Angle";
            series2.ValueDataMembers.AddRange(new string[] { "GoniometerScanGraphicsSeries2.Intensity" });
            series2.Visible = true;

            xrChart1.Series.Add(series1);
            xrChart1.Series.Add(series2);

            return xrChart1;
        }

        private object GetData()
        {
            var dataSource = GetGoniometerScanGraphicsCombinedSeriesData();
            return dataSource;
        }

        private IList<GoniometerScanGraphicsDTO> GetGoniometerScanGraphicsData()
        {
            return new List<GoniometerScanGraphicsDTO>
            {
                new GoniometerScanGraphicsDTO { Intensity = 0.1, Angle = 44},
                new GoniometerScanGraphicsDTO { Intensity = 0.2, Angle = 44.1},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 44.2},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 44.3},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 44.4},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 44.5},
                new GoniometerScanGraphicsDTO { Intensity = 0.5, Angle = 44.6},
                new GoniometerScanGraphicsDTO { Intensity = 2, Angle = 44.7},
                new GoniometerScanGraphicsDTO { Intensity = 9, Angle = 44.8},
                new GoniometerScanGraphicsDTO { Intensity = 35, Angle = 44.9},
                new GoniometerScanGraphicsDTO { Intensity = 60, Angle = 45},
                new GoniometerScanGraphicsDTO { Intensity = 35, Angle = 45.1},
                new GoniometerScanGraphicsDTO { Intensity = 8, Angle = 45.2},
                new GoniometerScanGraphicsDTO { Intensity = 2, Angle = 45.3},
                new GoniometerScanGraphicsDTO { Intensity = 0.5, Angle = 45.4},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 45.5},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 45.6},
                new GoniometerScanGraphicsDTO { Intensity = 0.3, Angle = 45.7},
                new GoniometerScanGraphicsDTO { Intensity = 0.2, Angle = 45.8},
                new GoniometerScanGraphicsDTO { Intensity = 0.2, Angle = 45.9},
                new GoniometerScanGraphicsDTO { Intensity = 0.1, Angle = 46},
            };
        }

        private IList<GoniometerScanGraphicsDTO> GetGoniometerScanGraphicsData2()
        {
            return new List<GoniometerScanGraphicsDTO>
            {
                new GoniometerScanGraphicsDTO { Intensity = 0.1, Angle = 44.8},
                new GoniometerScanGraphicsDTO { Intensity = 25, Angle = 44.8},
                new GoniometerScanGraphicsDTO { Intensity = 25, Angle = 45.2},
                new GoniometerScanGraphicsDTO { Intensity = 0.1, Angle = 45.2}
            };
        }

        private IList<GoniometerScanGraphicsCombinedSeriesDTO> GetGoniometerScanGraphicsCombinedSeriesData()
        {
            return new List<GoniometerScanGraphicsCombinedSeriesDTO>
            {
                new GoniometerScanGraphicsCombinedSeriesDTO
                {
                    GoniometerScanGraphicsSeries1 = GetGoniometerScanGraphicsData(),
                    GoniometerScanGraphicsSeries2 = GetGoniometerScanGraphicsData2()
                }
            };
        }
    }
}
