using System;
using DevExpress.XtraReports.UI;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class SpectrometerLayoutRpt
    {
        public SpectrometerLayoutRpt()
        {
            InitializeComponent();
        }
    }
}
