using System;
using DevExpress.XtraReports.UI;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class TestRpt
    {
        public TestRpt()
        {
            InitializeComponent();
        }
    }
}
