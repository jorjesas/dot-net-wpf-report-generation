using System;
using DevExpress.XtraReports.UI;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class XtraReport1
    {
        public XtraReport1()
        {
            InitializeComponent();
        }
    }
}
