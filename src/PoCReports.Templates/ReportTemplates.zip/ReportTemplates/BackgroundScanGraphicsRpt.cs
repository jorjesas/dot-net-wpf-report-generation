using System;
using DevExpress.XtraReports.UI;

namespace PoCReports.Templates.ReportTemplates
{
    public partial class BackgroundScanGraphicsRpt
    {
        public BackgroundScanGraphicsRpt()
        {
            InitializeComponent();
        }
    }
}
